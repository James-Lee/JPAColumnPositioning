/**
 * 
 */
package com.javateam.JPAColumnPositioning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author javateam
 *
 */
@SpringBootApplication
public class JPAColumnPositioningApplication {
    
	public static void main(String[] args) {
        SpringApplication.run(JPAColumnPositioningApplication.class, args);
    }
}